.. currentmodule:: imblearn

===============
Release history
===============

.. include:: whats_new/v0.10.rst

.. include:: whats_new/v0.9.rst

.. include:: whats_new/v0.8.rst

.. include:: whats_new/v0.7.rst

.. include:: whats_new/v0.6.rst

.. include:: whats_new/v0.5.rst

.. include:: whats_new/v0.4.rst

.. include:: whats_new/v0.3.rst

.. include:: whats_new/v0.2.rst

.. include:: whats_new/v0.1.rst
