﻿EditedNearestNeighbours
=============================================================

.. currentmodule:: imblearn.under_sampling

.. autoclass:: EditedNearestNeighbours

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~EditedNearestNeighbours.fit
      
      
        ~EditedNearestNeighbours.fit_resample
      
      
        ~EditedNearestNeighbours.get_params
      
      
        ~EditedNearestNeighbours.set_params
      
   
   

.. include:: imblearn.under_sampling.EditedNearestNeighbours.examples

.. raw:: html

    <div style='clear:both'></div>