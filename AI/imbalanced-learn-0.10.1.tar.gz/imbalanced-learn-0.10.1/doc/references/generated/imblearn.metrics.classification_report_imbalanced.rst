﻿classification_report_imbalanced
=====================================================================

.. currentmodule:: imblearn.metrics

.. autofunction:: classification_report_imbalanced

.. include:: imblearn.metrics.classification_report_imbalanced.examples

.. raw:: html

    <div style='clear:both'></div>