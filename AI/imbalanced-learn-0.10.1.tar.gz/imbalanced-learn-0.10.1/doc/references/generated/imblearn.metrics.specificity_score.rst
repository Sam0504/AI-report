﻿specificity_score
======================================================

.. currentmodule:: imblearn.metrics

.. autofunction:: specificity_score

.. include:: imblearn.metrics.specificity_score.examples

.. raw:: html

    <div style='clear:both'></div>