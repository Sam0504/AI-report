﻿AllKNN
============================================

.. currentmodule:: imblearn.under_sampling

.. autoclass:: AllKNN

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~AllKNN.fit
      
      
        ~AllKNN.fit_resample
      
      
        ~AllKNN.get_params
      
      
        ~AllKNN.set_params
      
   
   

.. include:: imblearn.under_sampling.AllKNN.examples

.. raw:: html

    <div style='clear:both'></div>