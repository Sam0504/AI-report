﻿make_index_balanced_accuracy
=================================================================

.. currentmodule:: imblearn.metrics

.. autofunction:: make_index_balanced_accuracy

.. include:: imblearn.metrics.make_index_balanced_accuracy.examples

.. raw:: html

    <div style='clear:both'></div>