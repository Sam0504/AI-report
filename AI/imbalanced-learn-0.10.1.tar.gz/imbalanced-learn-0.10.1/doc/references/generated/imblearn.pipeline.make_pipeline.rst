﻿make_pipeline
===================================================

.. currentmodule:: imblearn.pipeline

.. autofunction:: make_pipeline

.. include:: imblearn.pipeline.make_pipeline.examples

.. raw:: html

    <div style='clear:both'></div>