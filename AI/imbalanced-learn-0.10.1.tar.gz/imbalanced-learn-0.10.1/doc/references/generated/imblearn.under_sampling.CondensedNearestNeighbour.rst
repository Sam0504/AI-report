﻿CondensedNearestNeighbour
===============================================================

.. currentmodule:: imblearn.under_sampling

.. autoclass:: CondensedNearestNeighbour

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~CondensedNearestNeighbour.fit
      
      
        ~CondensedNearestNeighbour.fit_resample
      
      
        ~CondensedNearestNeighbour.get_params
      
      
        ~CondensedNearestNeighbour.set_params
      
   
   

.. include:: imblearn.under_sampling.CondensedNearestNeighbour.examples

.. raw:: html

    <div style='clear:both'></div>