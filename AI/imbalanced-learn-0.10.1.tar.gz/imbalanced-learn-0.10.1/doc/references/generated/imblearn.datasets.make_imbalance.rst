﻿make_imbalance
====================================================

.. currentmodule:: imblearn.datasets

.. autofunction:: make_imbalance

.. include:: imblearn.datasets.make_imbalance.examples

.. raw:: html

    <div style='clear:both'></div>