﻿NeighbourhoodCleaningRule
===============================================================

.. currentmodule:: imblearn.under_sampling

.. autoclass:: NeighbourhoodCleaningRule

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~NeighbourhoodCleaningRule.fit
      
      
        ~NeighbourhoodCleaningRule.fit_resample
      
      
        ~NeighbourhoodCleaningRule.get_params
      
      
        ~NeighbourhoodCleaningRule.set_params
      
   
   

.. include:: imblearn.under_sampling.NeighbourhoodCleaningRule.examples

.. raw:: html

    <div style='clear:both'></div>