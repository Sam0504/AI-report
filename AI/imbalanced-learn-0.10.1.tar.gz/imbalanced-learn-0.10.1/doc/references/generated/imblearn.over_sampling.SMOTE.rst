﻿SMOTE
==========================================

.. currentmodule:: imblearn.over_sampling

.. autoclass:: SMOTE

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~SMOTE.fit
      
      
        ~SMOTE.fit_resample
      
      
        ~SMOTE.get_params
      
      
        ~SMOTE.set_params
      
   
   

.. include:: imblearn.over_sampling.SMOTE.examples

.. raw:: html

    <div style='clear:both'></div>