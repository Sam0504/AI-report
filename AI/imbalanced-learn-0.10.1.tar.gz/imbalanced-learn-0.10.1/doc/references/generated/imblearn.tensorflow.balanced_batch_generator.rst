﻿balanced_batch_generator
================================================================

.. currentmodule:: imblearn.tensorflow

.. autofunction:: balanced_batch_generator

.. include:: imblearn.tensorflow.balanced_batch_generator.examples

.. raw:: html

    <div style='clear:both'></div>