﻿check_sampling_strategy
==========================================================

.. currentmodule:: imblearn.utils

.. autofunction:: check_sampling_strategy

.. include:: imblearn.utils.check_sampling_strategy.examples

.. raw:: html

    <div style='clear:both'></div>