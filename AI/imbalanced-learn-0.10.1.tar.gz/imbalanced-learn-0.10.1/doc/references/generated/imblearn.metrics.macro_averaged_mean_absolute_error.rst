﻿macro_averaged_mean_absolute_error
=======================================================================

.. currentmodule:: imblearn.metrics

.. autofunction:: macro_averaged_mean_absolute_error

.. include:: imblearn.metrics.macro_averaged_mean_absolute_error.examples

.. raw:: html

    <div style='clear:both'></div>