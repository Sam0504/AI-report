﻿check_neighbors_object
=========================================================

.. currentmodule:: imblearn.utils

.. autofunction:: check_neighbors_object

.. include:: imblearn.utils.check_neighbors_object.examples

.. raw:: html

    <div style='clear:both'></div>