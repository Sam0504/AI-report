﻿NearMiss
==============================================

.. currentmodule:: imblearn.under_sampling

.. autoclass:: NearMiss

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~NearMiss.fit
      
      
        ~NearMiss.fit_resample
      
      
        ~NearMiss.get_params
      
      
        ~NearMiss.set_params
      
   
   

.. include:: imblearn.under_sampling.NearMiss.examples

.. raw:: html

    <div style='clear:both'></div>