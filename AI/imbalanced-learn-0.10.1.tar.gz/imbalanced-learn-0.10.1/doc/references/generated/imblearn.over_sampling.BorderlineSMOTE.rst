﻿BorderlineSMOTE
====================================================

.. currentmodule:: imblearn.over_sampling

.. autoclass:: BorderlineSMOTE

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~BorderlineSMOTE.fit
      
      
        ~BorderlineSMOTE.fit_resample
      
      
        ~BorderlineSMOTE.get_params
      
      
        ~BorderlineSMOTE.set_params
      
   
   

.. include:: imblearn.over_sampling.BorderlineSMOTE.examples

.. raw:: html

    <div style='clear:both'></div>