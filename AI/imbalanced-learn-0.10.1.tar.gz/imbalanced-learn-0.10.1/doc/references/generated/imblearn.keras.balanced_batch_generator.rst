﻿balanced_batch_generator
===========================================================

.. currentmodule:: imblearn.keras

.. autofunction:: balanced_batch_generator

.. include:: imblearn.keras.balanced_batch_generator.examples

.. raw:: html

    <div style='clear:both'></div>