﻿SMOTENC
============================================

.. currentmodule:: imblearn.over_sampling

.. autoclass:: SMOTENC

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~SMOTENC.fit
      
      
        ~SMOTENC.fit_resample
      
      
        ~SMOTENC.get_params
      
      
        ~SMOTENC.set_params
      
   
   

.. include:: imblearn.over_sampling.SMOTENC.examples

.. raw:: html

    <div style='clear:both'></div>