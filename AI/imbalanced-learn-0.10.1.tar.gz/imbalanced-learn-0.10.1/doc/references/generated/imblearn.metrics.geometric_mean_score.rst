﻿geometric_mean_score
=========================================================

.. currentmodule:: imblearn.metrics

.. autofunction:: geometric_mean_score

.. include:: imblearn.metrics.geometric_mean_score.examples

.. raw:: html

    <div style='clear:both'></div>