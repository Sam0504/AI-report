﻿check_target_type
====================================================

.. currentmodule:: imblearn.utils

.. autofunction:: check_target_type

.. include:: imblearn.utils.check_target_type.examples

.. raw:: html

    <div style='clear:both'></div>