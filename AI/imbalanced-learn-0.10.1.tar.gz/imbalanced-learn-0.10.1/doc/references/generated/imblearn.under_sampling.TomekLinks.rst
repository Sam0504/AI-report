﻿TomekLinks
================================================

.. currentmodule:: imblearn.under_sampling

.. autoclass:: TomekLinks

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~TomekLinks.fit
      
      
        ~TomekLinks.fit_resample
      
      
        ~TomekLinks.get_params
      
      
        ~TomekLinks.is_tomek
      
      
        ~TomekLinks.set_params
      
   
   

.. include:: imblearn.under_sampling.TomekLinks.examples

.. raw:: html

    <div style='clear:both'></div>