﻿sensitivity_score
======================================================

.. currentmodule:: imblearn.metrics

.. autofunction:: sensitivity_score

.. include:: imblearn.metrics.sensitivity_score.examples

.. raw:: html

    <div style='clear:both'></div>