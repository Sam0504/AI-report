﻿SMOTEENN
=======================================

.. currentmodule:: imblearn.combine

.. autoclass:: SMOTEENN

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~SMOTEENN.fit
      
      
        ~SMOTEENN.fit_resample
      
      
        ~SMOTEENN.get_params
      
      
        ~SMOTEENN.set_params
      
   
   

.. include:: imblearn.combine.SMOTEENN.examples

.. raw:: html

    <div style='clear:both'></div>