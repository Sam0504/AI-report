﻿sensitivity_specificity_support
====================================================================

.. currentmodule:: imblearn.metrics

.. autofunction:: sensitivity_specificity_support

.. include:: imblearn.metrics.sensitivity_specificity_support.examples

.. raw:: html

    <div style='clear:both'></div>