﻿KMeansSMOTE
================================================

.. currentmodule:: imblearn.over_sampling

.. autoclass:: KMeansSMOTE

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~KMeansSMOTE.fit
      
      
        ~KMeansSMOTE.fit_resample
      
      
        ~KMeansSMOTE.get_params
      
      
        ~KMeansSMOTE.set_params
      
   
   

.. include:: imblearn.over_sampling.KMeansSMOTE.examples

.. raw:: html

    <div style='clear:both'></div>