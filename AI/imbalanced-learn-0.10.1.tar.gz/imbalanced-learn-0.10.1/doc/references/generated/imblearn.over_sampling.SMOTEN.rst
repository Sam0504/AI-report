﻿SMOTEN
===========================================

.. currentmodule:: imblearn.over_sampling

.. autoclass:: SMOTEN

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~SMOTEN.fit
      
      
        ~SMOTEN.fit_resample
      
      
        ~SMOTEN.get_params
      
      
        ~SMOTEN.set_params
      
   
   

.. include:: imblearn.over_sampling.SMOTEN.examples

.. raw:: html

    <div style='clear:both'></div>