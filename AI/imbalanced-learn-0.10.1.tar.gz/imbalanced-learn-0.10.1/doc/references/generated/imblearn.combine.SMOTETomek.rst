﻿SMOTETomek
=========================================

.. currentmodule:: imblearn.combine

.. autoclass:: SMOTETomek

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~SMOTETomek.fit
      
      
        ~SMOTETomek.fit_resample
      
      
        ~SMOTETomek.get_params
      
      
        ~SMOTETomek.set_params
      
   
   

.. include:: imblearn.combine.SMOTETomek.examples

.. raw:: html

    <div style='clear:both'></div>