﻿FunctionSampler
======================================

.. currentmodule:: imblearn

.. autoclass:: FunctionSampler

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~FunctionSampler.fit
      
      
        ~FunctionSampler.fit_resample
      
      
        ~FunctionSampler.get_params
      
      
        ~FunctionSampler.set_params
      
   
   

.. include:: imblearn.FunctionSampler.examples

.. raw:: html

    <div style='clear:both'></div>