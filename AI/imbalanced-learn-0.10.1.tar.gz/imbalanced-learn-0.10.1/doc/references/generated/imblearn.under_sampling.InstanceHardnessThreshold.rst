﻿InstanceHardnessThreshold
===============================================================

.. currentmodule:: imblearn.under_sampling

.. autoclass:: InstanceHardnessThreshold

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~InstanceHardnessThreshold.fit
      
      
        ~InstanceHardnessThreshold.fit_resample
      
      
        ~InstanceHardnessThreshold.get_params
      
      
        ~InstanceHardnessThreshold.set_params
      
   
   

.. include:: imblearn.under_sampling.InstanceHardnessThreshold.examples

.. raw:: html

    <div style='clear:both'></div>