﻿SVMSMOTE
=============================================

.. currentmodule:: imblearn.over_sampling

.. autoclass:: SVMSMOTE

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~SVMSMOTE.fit
      
      
        ~SVMSMOTE.fit_resample
      
      
        ~SVMSMOTE.get_params
      
      
        ~SVMSMOTE.set_params
      
   
   

.. include:: imblearn.over_sampling.SVMSMOTE.examples

.. raw:: html

    <div style='clear:both'></div>