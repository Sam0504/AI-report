﻿RepeatedEditedNearestNeighbours
=====================================================================

.. currentmodule:: imblearn.under_sampling

.. autoclass:: RepeatedEditedNearestNeighbours

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~RepeatedEditedNearestNeighbours.fit
      
      
        ~RepeatedEditedNearestNeighbours.fit_resample
      
      
        ~RepeatedEditedNearestNeighbours.get_params
      
      
        ~RepeatedEditedNearestNeighbours.set_params
      
   
   

.. include:: imblearn.under_sampling.RepeatedEditedNearestNeighbours.examples

.. raw:: html

    <div style='clear:both'></div>