﻿ClusterCentroids
======================================================

.. currentmodule:: imblearn.under_sampling

.. autoclass:: ClusterCentroids

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~ClusterCentroids.fit
      
      
        ~ClusterCentroids.fit_resample
      
      
        ~ClusterCentroids.get_params
      
      
        ~ClusterCentroids.set_params
      
   
   

.. include:: imblearn.under_sampling.ClusterCentroids.examples

.. raw:: html

    <div style='clear:both'></div>