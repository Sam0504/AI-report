﻿RandomUnderSampler
========================================================

.. currentmodule:: imblearn.under_sampling

.. autoclass:: RandomUnderSampler

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~RandomUnderSampler.fit
      
      
        ~RandomUnderSampler.fit_resample
      
      
        ~RandomUnderSampler.get_params
      
      
        ~RandomUnderSampler.set_params
      
   
   

.. include:: imblearn.under_sampling.RandomUnderSampler.examples

.. raw:: html

    <div style='clear:both'></div>