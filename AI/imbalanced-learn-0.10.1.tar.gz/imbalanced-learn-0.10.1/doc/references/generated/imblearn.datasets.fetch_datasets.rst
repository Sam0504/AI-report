﻿fetch_datasets
====================================================

.. currentmodule:: imblearn.datasets

.. autofunction:: fetch_datasets

.. include:: imblearn.datasets.fetch_datasets.examples

.. raw:: html

    <div style='clear:both'></div>