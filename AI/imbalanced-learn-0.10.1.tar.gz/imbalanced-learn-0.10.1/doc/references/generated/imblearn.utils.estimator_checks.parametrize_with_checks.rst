﻿parametrize_with_checks
===========================================================================

.. currentmodule:: imblearn.utils.estimator_checks

.. autofunction:: parametrize_with_checks

.. include:: imblearn.utils.estimator_checks.parametrize_with_checks.examples

.. raw:: html

    <div style='clear:both'></div>