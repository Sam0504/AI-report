﻿BalancedBaggingClassifier
=========================================================

.. currentmodule:: imblearn.ensemble

.. autoclass:: BalancedBaggingClassifier

   

   
   .. rubric:: Methods

   .. autosummary::
   
      
      
        ~BalancedBaggingClassifier.decision_function
      
      
        ~BalancedBaggingClassifier.fit
      
      
        ~BalancedBaggingClassifier.get_params
      
      
        ~BalancedBaggingClassifier.predict
      
      
        ~BalancedBaggingClassifier.predict_log_proba
      
      
        ~BalancedBaggingClassifier.predict_proba
      
      
        ~BalancedBaggingClassifier.score
      
      
        ~BalancedBaggingClassifier.set_params
      
   
   

.. include:: imblearn.ensemble.BalancedBaggingClassifier.examples

.. raw:: html

    <div style='clear:both'></div>