.. _tensorflow_ref:

Batch generator for TensorFlow
==============================

.. automodule:: imblearn.tensorflow
    :no-members:
    :no-inherited-members:

.. currentmodule:: imblearn

.. autosummary::
   :toctree: generated/
   :template: function.rst

   tensorflow.balanced_batch_generator
