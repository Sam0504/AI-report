.. _pipeline_ref:

Pipeline
========

.. automodule:: imblearn.pipeline
    :no-members:
    :no-inherited-members:

.. currentmodule:: imblearn.pipeline

.. autosummary::
   :toctree: generated/
   :template: class.rst

   Pipeline

.. autosummary::
   :toctree: generated/
   :template: function.rst

   make_pipeline
